﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Synoptic
{
    public Appointment(DateTime date)
    {
        Date = date;
        Tags = new List<Tag>();
    }

    public string Title { get; set; }
    public DateTime Date { get; set; }
    public int Id { get; set; }
    public List<Tag> Tags { get; private set; }

    public void AddTag(Tag tag)
    {
        Tags.Add(tag);
    }

    public void SendTo(EmailAddress email)
    {
        // Code that sends details of appointment to email address
    }
}
