﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synoptic
{
    public class AppointmentDetails : Appointment
    {
        public string AdditionalDetails { get; set; }
    }

    public class Appointment
    {
        public Appointment(DateTime date)
        {
            Date = date;
            Tags = new List<Tag>();
            Details = new AppointmentDetails();
        }

        public string Title { get; set; }
        public DateTime Date { get; set; }
        public int Id { get; set; }
        public List<Tag> Tags { get; private set; }
        public AppointmentDetails Details { get; set; }

        public void AddTag(Tag tag)
        {
            Tags.Add(tag);
        }

        public void SendTo(EmailAddress email)
        {
            if (email != null)
            {
                Console.WriteLine($"Sending details of the appointment to {email.FullName} at {email.Recipient}");
                Console.WriteLine($"Title: {Title}");
                Console.WriteLine($"Date: {Date}");

            }
            else
            {
                throw new ArgumentNullException(nameof(email), "Email address cannot be null.");
            }
        }
    }


}
