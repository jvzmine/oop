﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synoptic
{
    public class AppointmentWithNotification : Appointment
    {
        public EmailAddress Recipient { get; set; }

        public AppointmentWithNotification(DateTime date, EmailAddress recipient)
            : base(date)
        {
            Recipient = recipient;
            SendNotification();
        }

        private void SendNotification()
        {

            Console.WriteLine($"Notification sent to {Recipient.FullName} for the appointment on {Date}.");
        }
    }

}
