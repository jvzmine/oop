﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synoptic
{
    internal class Calendar
    {
        private string title;
        private DateTime startDate;
        private string user;
        private List<Appointment> appointments;

        public string Title
        {
            get { return title; }
        }

        public DateTime StartDate
        {
            get { return startDate; }
            private set
            {
                if (value > DateTime.Now)
                {
                    throw new Exception("Invalid Date");
                }
                startDate = value;
            }
        }

        public string User
        {
            get { return user; }
        }

        public Calendar(string title, DateTime startDate, string user)
        {
            this.title = title;
            this.startDate = startDate;
            this.user = user;
            this.appointments = new List<Appointment>();
        }

        public void AddAppointment(Appointment appointment)
        {
            if (appointment.Date > DateTime.Now)
            {
                appointments.Add(appointment);
            }
            else
            {
                throw new Exception("Appointment date must be in the future.");
            }
        }
    }
}





